package com.example.hotelbookingapp;

public class hotel {
    private  String roomtype;
    private double roomrate;
    private  String roomimage1;
    private  String roomimage2;

    public hotel(String roomtype, double roomrate, String roomimage1, String roomimage2) {
        this.roomtype = roomtype;
        this.roomrate = roomrate;
        this.roomimage1 = roomimage1;
        this.roomimage2 = roomimage2;
    }

    public String getRoomtype() {
        return roomtype;
    }

    public double getRoomrate() {
        return roomrate;
    }

    public String getRoomimage1() {
        return roomimage1;
    }

    public String getRoomimage2() {
        return roomimage2;
    }


}
