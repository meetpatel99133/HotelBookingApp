package com.example.hotelbookingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener, AdapterView.OnItemSelectedListener, CompoundButton.OnCheckedChangeListener, View.OnClickListener {
    Spinner sp;
    ImageView img1,img2;
    TextView price,nt;
    SeekBar seek;
    RadioButton rd1,rd2,rd3,rd4;
    CheckBox ch1,ch2,ch3;
    Button btn;
    ArrayList<hotel> hotelList = new ArrayList<hotel>();
    ArrayList<String> name = new ArrayList<>();

    public static double  currentprice = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sp = findViewById(R.id.sp1);
        img1 = findViewById(R.id.img1);
        img2 = findViewById(R.id.img2);
        price = findViewById(R.id.price);
        seek = findViewById(R.id.seekBar);
        nt = findViewById(R.id.night);
        sp.setOnItemSelectedListener(this);
        seek.setOnSeekBarChangeListener(this);
        btn  = findViewById(R.id.btn);
        btn.setOnClickListener(this);


        rd1 = findViewById(R.id.rdnormal);
        rd2 = findViewById(R.id.rdsuper);
        rd3 = findViewById(R.id.rdluxury);
        rd4 =findViewById(R.id.rdsuite);


        ch1 = findViewById(R.id.ch1);
        ch2 = findViewById(R.id.ch2);
        ch3 = findViewById(R.id.ch3);



        rd1.setOnClickListener(new RadioButtonAction());
        rd2.setOnClickListener(new RadioButtonAction());
        rd3.setOnClickListener(new RadioButtonAction());
        rd4.setOnClickListener(new RadioButtonAction());

        ch1.setOnCheckedChangeListener(this);
        ch2.setOnCheckedChangeListener(this);
        ch3.setOnCheckedChangeListener(this);



        filldata();
        ArrayAdapter aa =  new ArrayAdapter(this,android.R.layout.simple_dropdown_item_1line,name);
        sp.setAdapter(aa);
        sp.setOnItemSelectedListener(this);
        price.setText(String.valueOf(hotelList.get(0).getRoomrate()));
        currentprice = hotelList.get(0).getRoomrate();
        int imgId1 = getResources().getIdentifier(hotelList.get(0).getRoomimage1(),"drawable",getPackageName());
        img1.setImageResource(imgId1);
        int imgId2 = getResources().getIdentifier(hotelList.get(0).getRoomimage2(),"drawable",getPackageName());
        img2.setImageResource(imgId2);



    }
    public  void filldata() {
        hotelList.add(new hotel("Single Room",69,"singleone","singlebed2"));
        hotelList.add(new hotel("Double Room",79,"double1","double2"));
        hotelList.add(new hotel("Triple Room",99.99,"triple1","triple2"));
        hotelList.add(new hotel("Queen Room",111,"queen1","queen2"));
        hotelList.add(new hotel("King Room",119,"king1","king2"));
        for (int i = 0;i<hotelList.size();i++) {
            name.add(hotelList.get(i).getRoomtype());
        }
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        nt.setText(String.valueOf(progress));
        double total = currentprice * Double.parseDouble(nt.getText().toString());
        price.setText(String.format("%.2f",total));
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        price.setText(String.valueOf(hotelList.get(position).getRoomrate()));

        rd1.setChecked(true);
        ch1.setChecked(false);
        ch2.setChecked(false);
        ch3.setChecked(false);
        nt.setText("1");
        seek.setProgress(1);
        int imgId1 = getResources().getIdentifier(hotelList.get(position).getRoomimage1(),"drawable",getPackageName());
        img1.setImageResource(imgId1);
        int imgId2 = getResources().getIdentifier(hotelList.get(position).getRoomimage2(),"drawable",getPackageName());
        img2.setImageResource(imgId2);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        double currentPrice = Double.parseDouble(price.getText().toString());
        if(buttonView.getId() == R.id.ch1)
            if(ch1.isChecked())
                currentPrice += 25;
            else
                currentPrice -= 25;
        if(buttonView.getId() == R.id.ch2)
            if(ch2.isChecked())
                currentPrice += 20;
            else
                currentPrice -= 20;

        if(buttonView.getId() == R.id.ch3)
            if(ch3.isChecked())
                currentPrice = currentPrice * 1.10;
            else
                currentPrice = currentPrice / 1.10;
        price.setText(String.format("%.2f",currentPrice));
    }

    @Override
    public void onClick(View v) {
        double currentPrice = Double.parseDouble(price.getText().toString());
        double amount = currentPrice * Double.parseDouble(nt.getText().toString());
        price.setText(String.format("%.2f",amount*1.13));
    }

    private  class RadioButtonAction implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            if (v.getId() == R.id.rdnormal)
                price.setText(String.valueOf(currentprice));
            else if(v.getId() == R.id.rdsuper)
                price.setText(String.format("%.2f",currentprice * 1.25));
            else if(v.getId() == R.id.rdluxury)
                price.setText(String.format("%.2f",currentprice * 1.50));
            else if (v.getId() == R.id.rdsuite)
                price.setText(String.format("%.2f",currentprice* 2));

        }
    }

}